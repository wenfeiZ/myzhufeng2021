vue+component+vue-router+vuex+axios
库：相当于功能比较全的产品,想用时拿取产品中的一部分使用就可以
框架：为了解决一系列问题而生产出的产品,使用时只能按照他的规定来使用
## 指令  v-xxx 表示有特定的功能，用来操作DOM元素
v-text 默认渲染成文本
v-html 渲染成html
v-once 只渲染一次，再更改时直接从缓存中获取
v-for 数组，字符串 对象  想遍历谁，就在谁上面加v-for  key 增加唯一个值，避免同一父元素下相同元素复用
v-if /v-else/v-else-if 操作DOM元素 一旦条件不成立，DOM元素不存在
v-show 更改样式。显示/隐藏
v-if不要跟v-for在同一个标签使用 v-for优先级高于v-if
v-model 双向绑定
    .lazy 
    .number
    .trim
v-on 简写@ 绑定事件
    .stop  阻止冒泡
    .prevent 阻止默认行为
    .capture  采取捕获的方式
    .self  操作是自己时才会触发
    .once  只触发一次
    .passive 处理事件函数中不会调用preventDefault函数，减少额外的监听，提高了性能   不能和.prevent同时使用
v-bind 简写： 绑定动态的属性
