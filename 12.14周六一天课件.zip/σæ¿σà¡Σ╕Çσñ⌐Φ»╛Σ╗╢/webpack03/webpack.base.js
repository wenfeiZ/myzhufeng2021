let path  = require('path');
const dev = require('./webpack.dev');
const prod = require('./webpack.prod');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const AddAssetHtmlCdnPlugin = require('add-asset-html-cdn-webpack-plugin');

const webpack = require('webpack');
 const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const merge = require('webpack-merge');
const HappyPack = require('happypack');
let htmlPlugin = ['index', 'other'].map(chunckName => {
    return new HtmlWebpackPlugin({
        template: `./src/${chunckName}.html`,
        filename: `${chunckName}.html`,
        chunks: [chunckName]
    })
})
module.exports = (env)=>{
    let base = {
        
        // externals:{
        //     'jquery':'$'  //$外部变量 不需要打包
        // },
        resolve:{
            extensions:['.js',".jsx",'.json','.css','.ts','.tsx','.vue'],
            alias:{
            //    "@":path.resolve(__dirname,'src'),
               "test":path.resolve(__dirname,'src/test') 
            }
        },
        entry:
        {
        'index':'./src/index.js',
        'other':'./src/other.js'
        },   
        output:{
            filename:'[name].js',
            path:path.resolve(__dirname,"dist"),
            chunkFilename:'[name].min.js'
        },
        module:{
            rules:[  //从下往上
                // {
                //     test:/\.js$/,
                //     use:'eslint-loader',
                //     enforce:'pre'
                // },
                // {
                //    test:require.resolve('jquery'),
                //    use:{
                //        loader:'expose-loader',
                //        options:'$$' 
                //    }    
                // },
                {
                    test:/\.css$/,
                    //[] {} ''
                    use:[
                        // {
                        //     loader:MiniCssExtractPlugin.loader
                        // }
                        "style-loader"
                        ,'css-loader']  //从右往左
                },
                {
                    test:/\.less$/,
                    use:['style-loader','css-loader','less-loader']
                },
                {
                    test:/\.(jpg|jpeg|gif)$/,
                    use:[
                        'file-loader',
                        {
                            loader: 'image-webpack-loader',
                            options: {
                              mozjpeg: {
                                progressive: true,
                                quality: 65   //图片品质
                              },
                              // optipng.enabled: false will disable optipng
                              optipng: {
                                enabled: false,
                              },
                              pngquant: {
                                quality: [0.65, 0.90],
                                speed: 4
                              },
                              gifsicle: {
                                interlaced: false,
                              },
                              // the webp option will enable WEBP
                              webp: {
                                quality: 75
                              }
                            }
                          },
                        ],
                     
                },
                
                // {
                //     test:/\.(jpg|jpeg|gif)$/,
                //     use:{
                //         loader:'url-loader',  //小于100kb作为base64输出，若大于100kb会自动调用file-loader,打包成文件输出
                //           options:{
                //               limit:10*1024,  
                //               outputPath:'img',
                //             //   publicPath:'http://www.zhufeng.peixun/img'  设置访问的前缀 比如图片放在一个cdn里
                //         }  
                //     }  
                // },
                {
                    test:/\.(eot|svg|ttf|woff|woff2)$/,
                    use:'file-loader'
                },
                {
                    test:/\.js$/,
                    use:'babel-loader',
                    include:path.resolve(__dirname,'src'), //需求编译的js文件的目录
                    exclude:/node_modules/  //排除需要编译js文件的目录
                }
            ]
        },
        plugins:[
            // new HappyPack({
            //     id: 'styles',
            //     threads: 2,
            //     loaders: [ 'style-loader', 'css-loader', 'less-loader' ]
            //   }),
            
            new webpack.HotModuleReplacementPlugin(),
            new MiniCssExtractPlugin({
                filename:'css/main.css'
            }),
            // new webpack.ProvidePlugin({
            //       "$$" :'jquery' ,    //$是来自jquery,每个模块都注入变量$,但不是注入在全局下
            //       '_map':['lodash','map']
            // }),
            
            ...htmlPlugin
            // new HtmlWebpackPlugin({
            //     template:'./src/index.html',
            //     filename:'index.html',
            //     hash:true
            // }),
            // new AddAssetHtmlCdnPlugin(true,{
            //     'jquery':'https://code.jquery.com/jquery-3.4.1.min.js'
            // })
    
        ]
    }
    if(env.development){ 
       return merge(base,dev)            //base+dev
    }else{
       return merge(base,prod)          //base+prod
    }
}
