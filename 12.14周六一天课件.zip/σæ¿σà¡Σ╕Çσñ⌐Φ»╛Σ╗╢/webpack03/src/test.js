let plus = (a,b)=>{
    return a+b+3;
}
let minus  = (a,b)=>{
     return a-b   
}

export default plus