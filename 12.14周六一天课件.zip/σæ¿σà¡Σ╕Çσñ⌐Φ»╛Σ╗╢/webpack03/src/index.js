// import sum from './sum';
// import $ from 'jquery';
// import _ from 'lodash';
// import test from 'test';
// console.log(1);
// console.log(test(10,5))
// console.log($,_);

//require('expose-loader?$$!jquery') //jquery放在全局的$
// let res = _map([3,4,5],function(n){
//     return n*n;
// })
// console.log(res)
// console.log(window.$$);
// function fn(a,b){
//        let res = a+b
//        consee.log(2);
//        return res;     
// }
// fn(2,3)
// console.log(111);
import url  from './timg.jpeg';
let oImg = new Image();
oImg.src = url;
document.body.appendChild(oImg);
// import plus from './test';
// let oP = document.createElement('p');
// let button = document.createElement('button');
// button.innerHTML = "按钮"
// oP.innerHTML = plus(10,5);
// document.body.appendChild(oP);
// document.body.appendChild(button);
//js内容的热更新
// if(module.hot){
//    module.hot.accept('./test',()=>{
//        let plus = require('./test').default;
//        oP.innerHTML = plus(20,5)
//    }) 
// }

//懒加载 点击后动态加载文件
// webpackChunkName  webpackPrefetch 预引入   webpackPreload 预加载
// button.addEventListener('click',function(){
//     import(/*webpackPreload:true */'./test').then(({default:m})=>{
//         oP.innerHTML = m(20,10);
//     })
// })
