// class Person{
//     @readonly
//     first = 1
// }
// function readonly(target,name,descriptor){
//     descriptor.writable = false;  //不可更改
// }

// let p = new Person();
// p.first = 100;

// export default (a,b)=>{
//     return a+b
// }

let a = 1;
let b = 2;
let c = 3;
let d = a+b+c;
export default d;