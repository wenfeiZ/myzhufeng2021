// import './icon/iconfont.css';
//import sum from './sum'
// import "./index.css";
// console.log(sum(10,20));

// import url from './timg.jpeg';
// import { SourceNode } from '../../../Library/Caches/typescript/3.6/node_modules/@types/source-list-map';
// let oImg = new Image();
// oImg.src = url;
// document.body.appendChild(oImg);

// let i = document.createElement('i');
// i.className = "iconfont icon-caidan";
// document.body.appendChild(i);
// console.log("zhufeng".includes('g'))
//草案
//装饰器 语法糖
// @fn
// class Son{
//     a = 1
// }
// function fn(target){
//     target.flag = true;
//     console.log(target);
// }
// let s = new Son();

// console.log(Son.flag)

let xhr = new XMLHttpRequest();
xhr.open('get',"/api/user",true);
xhr.onreadystatechange = function(){
    console.log(xhr.response);
}
xhr.send();


