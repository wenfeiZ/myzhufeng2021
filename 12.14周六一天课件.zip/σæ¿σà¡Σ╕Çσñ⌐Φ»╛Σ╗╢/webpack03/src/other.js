import $ from 'jquery';
import _ from 'lodash';
console.log($,_);