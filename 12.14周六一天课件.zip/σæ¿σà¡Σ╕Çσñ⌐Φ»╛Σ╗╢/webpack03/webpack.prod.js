const {BundleAnalyzerPlugin} = require('webpack-bundle-analyzer')
const OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin');//压缩css
const TerserJSPlugin = require('terser-webpack-plugin');
module.exports = {
    mode:"production",
    optimization:{
     minimizer:[new OptimizeCssAssetsPlugin()],
      // splitChunks: {
            //     chunks: 'all', //异步  all 所有
            //     minSize: 30000, //至少30kb才去抽离
            //     maxSize: 0,
            //     minChunks: 1,//至少抽离第三方模块1个
            //     maxAsyncRequests: 5,//最大异步请求次数
            //     maxInitialRequests: 3,//首屏加载的请求次数
            //     automaticNameDelimiter: '~',//文件之间的连接符
            //     name: true, //是否可更改名字
            //     cacheGroups: { //缓存组，可以设置一些规则
            //       vendors: {
            //         test: /[\\/]node_modules[\\/]/,
            //         priority: -10
            //       },
            //       default: {
            //         minChunks: 2,
            //         priority: -2, //优先级
            //         reuseExistingChunk: true
            //       }
            //     }
            //   }
    },
    plugins:[
        new BundleAnalyzerPlugin(),
    ]
}