### 暴露全局的变量
1）直接使用cdn的方式
2）providePlugin  给每个模块注入变量
3) 暴露在全局下 expose-loader

### eslint.js
eslint eslint-loader

### sourceMap(代码排查)
https://webpack.docschina.org/configuration/devtool/#devtool
https://www.cnblogs.com/wangyingblog/p/7027540.html

开发环境
cheap-module-eval-source-map
生成环境
cheap-module-source-map

### Tree-shaking&scopeHosting(生成环境下)
- sideEffects 

### 热更新
### 懒加载（动态加载模块）
webpackPrefetch 利用浏览器空闲时间，把动态模块加载完成并引入进来
webpackPreload  跟主模块的代码同时进行加载
### 打包文件分析工具（生成环境下使用）
- webpack-bundle-analyzer
### splitChunks
  
### resolve解析
- extensions 添加扩展名进行匹配
- alias 设置别名
### happypack
- 多线程打包,把不同的逻辑交给不同的线程处理
### 根据mode分离配置环境 
- webpack.base.js  公共的配置
- webpack.dev.js   开发环境的配置
- webpack.prod.js  生成环境的配置
### 图片压缩
- image-webpack-loader