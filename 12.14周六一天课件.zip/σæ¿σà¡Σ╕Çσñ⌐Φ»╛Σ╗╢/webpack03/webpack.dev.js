const {CleanWebpackPlugin} = require('clean-webpack-plugin');
module.exports  = {
    mode:'development',
    devtool:'cheap-module-eval-source-map',
    devServer:{
        port:7777,
        // open:true,
        contentBase:"static",
        hot:true,
        before: function(app, server) {  //表示启动一个端口号为7777服务
            app.get('/api/user', function(req, res) {
              res.json({ custom: 'response' });
            });
          }
        // proxy:{ //启动代理
        //     '/api':{
        //         target:'http://localhost:8000',
        //         secure: false,  //若为true则表示以https开头
        //         pathRewrite: {'^/api' : ''},//重写地址
        //         changeOrigin:true //把请求头当中的host改成服务器的地址
        //     }
        // }
    },
    plugins:[
        new CleanWebpackPlugin()
    ]
}