let express = require('express');
let app = express();
app.get('/user',function(req,res){
    console.log(req.headers);
    res.json({name:'zf'})
})
app.listen(8000,function(){
    console.log('8000这个端口号的服务已启动')
})
