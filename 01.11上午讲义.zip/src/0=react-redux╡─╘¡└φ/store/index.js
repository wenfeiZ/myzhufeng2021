/*
 * 创建STORE 
 */
import {
	createStore,
	applyMiddleware
} from 'redux';
//=>在控制台输出每一次派发任务的情况
import reduxLogger from 'redux-logger';
//=>管控action creators中异步处理的
import reduxThunk from 'redux-thunk';
import reduxPromise from 'redux-promise';
import reducer from './reducers/index';

//=>applyMiddleware：应用中间件
const store = createStore(reducer, applyMiddleware(reduxLogger, reduxThunk, reduxPromise));
export default store;