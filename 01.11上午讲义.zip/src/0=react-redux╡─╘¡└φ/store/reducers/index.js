/*
 * 把各版块的小REDUCER合成一个大的REDUCER 
 */
import {
	combineReducers
} from 'redux';
import voteReducer from './voteReducer';
import userReducer from './userReducer';

//=>combineReducers合并reducer
// 为了防止各个reducer中的状态合并后会冲突，合并后的reducer按照属性进行模块的划分
/*
 state={
	 //=>模块名是combine的时候指定的属性名
	 vote:{
		 title:'',
		 supNum:0,
		 oppNum:0
	 },
	 user:{
		 title:''
	 }
 };

 => store.getState().vote.supNum 再获取状态就要指定对应的模块了
 */
const reducer = combineReducers({
	vote: voteReducer,
	user: userReducer
});
export default reducer;