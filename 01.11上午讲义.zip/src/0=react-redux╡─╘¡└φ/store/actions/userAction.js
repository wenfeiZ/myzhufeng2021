import * as TYPES from '../action-types';
const userAction = {

};
export default userAction;