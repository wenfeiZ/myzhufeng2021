/*
 * 每个模块的ACTION：把需要DISPATCH派发的对象用各个方法包起来，返回的结果就是需要派发的对象 
 */
import * as TYPES from '../action-types';
const voteAction = {
	support(payload) {
		//=>搞一个异步操作
		/* setTimeout(_ => {
			return {
				type: TYPES.VOTE_SUPPORT,
				payload
			};
		}, 1000); =>默认不支持异步处理 */

		/* reduxThunk */
		/* return dispatch => {
			setTimeout(_ => {
				dispatch({
					type: TYPES.VOTE_SUPPORT,
					payload
				});
			}, 1000);
		}; */

		/* reduxPromise：传递给reducer的action对象中的参数必须叫做payload，叫别的值都无法传递过去 */
		return {
			type: TYPES.VOTE_SUPPORT,
			payload: new Promise(resolve => {
				setTimeout(_ => {
					resolve(10);
				}, 1000);
			})
		};

		//=>思考任务：中间件的原理就是把dispatch方法重构，回去后慢慢研究中间件的原理 createStore(reducer,enhancer)  applyMiddleware  redux-thunk/redux-promise...
	},
	oppose(payload) {
		return {
			type: TYPES.VOTE_OPPOSE,
			num: payload
		};
	}
};
export default voteAction;