/*
 * 派发行为标识ACTION.TYPE的宏管理 
 */
export const VOTE_SUPPORT = 'VOTE_SUPPORT';
export const VOTE_OPPOSE = 'VOTE_OPPOSE';