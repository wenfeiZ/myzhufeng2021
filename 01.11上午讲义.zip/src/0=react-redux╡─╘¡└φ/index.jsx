import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import Vote from './component/Vote';
import store from './store/index';

ReactDOM.render(<Provider store={store}>
	<Vote />
</Provider>, document.getElementById('root'));

/*
 * react-redux是专门为react项目封装的redux处理库：简化redux在组件中的应用代码
 *   Provider组件
 *     把store挂载到祖先元素的上下文中，方便后期后台组件的调用
 *   connect高阶函数
 *     把redux容器中存储的状态以及需派发的行为任务都通过属性传递给当前组件
 *     自动会向事件池中追加当前组件重新渲染的方法，保证状态更新，组件会重新渲染
 */