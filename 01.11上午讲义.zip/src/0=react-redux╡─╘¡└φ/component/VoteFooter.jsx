import React from 'react';
import { connect } from 'react-redux';
import action from '../store/actions/index';
class VoteFooter extends React.Component {
	render() {
		let { support, oppose } = this.props;
		return <footer>
			<button onClick={support.bind(null, 20)}>支持</button>
			<button onClick={oppose.bind(null, 10)}>反对</button>
		</footer>;
	}
}
/* function mapDispatchToProps(dispatch) {
	//=>dispatch:store.dispatch  =>dispatch({type:'xxx'...})
	return {
		support(payload) {
			dispatch(action.vote.support(payload));
		},
		oppose(payload) {
			dispatch(action.vote.oppose(payload));
		}
	};
} */
export default connect(null, action.vote)(VoteFooter);

//=>connect会默认帮我们把actionCreator对象变为mapDispatchToProps这种函数的模式
/* connect(null, {
	support(payload) {
		return {
			type: TYPES.VOTE_SUPPORT,
			payload
		};
	},
	oppose(payload) {
		return {
			type: TYPES.VOTE_OPPOSE,
			num: payload
		};
	}
})(VoteFooter); */