import React from 'react';
import { connect } from 'react-redux';
class VoteMain extends React.Component {
	render() {
		let { supNum, oppNum } = this.props;
		return <main>
			<p>支持人数：{supNum}</p>
			<p>反对人数：{oppNum}</p>
		</main>;
	}
}
export default connect(state => state.vote)(VoteMain);