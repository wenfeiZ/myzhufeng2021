import React from 'react';
import VoteHead from './VoteHead';
import VoteMain from './VoteMain';
import VoteFooter from './VoteFooter';

class Vote extends React.Component {
	render() {
		return <section>
			<VoteHead/>
			<VoteMain/>
			<VoteFooter/>
		</section>;
	}
}
export default Vote;