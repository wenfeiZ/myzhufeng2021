import React from 'react';
import ReactDOM from 'react-dom';
import Task from './pages/Task';

/* ANTD */
import { ConfigProvider } from 'antd';
import zhCN from 'antd/es/locale/zh_CN';
import 'antd/dist/antd.css';

/* 导入公共样式资源 */
import './assets/reset.min.css';
import './assets/common.less';

ReactDOM.render(<ConfigProvider locale={zhCN}>
	<Task />
</ConfigProvider>, document.getElementById('root'));