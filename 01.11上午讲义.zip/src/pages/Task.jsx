import React from 'react';
import './Task.less';
import { Button, Tag, Table } from 'antd';

class Task extends React.Component {
	state = {
		columns: [{
			title: "编号",
			dataIndex: ""
		}, {
			title: "描述",
			dataIndex: ""
		}, {
			title: "时间",
			dataIndex: ""
		}, {
			title: "状态",
			dataIndex: ""
		}, {
			title: "操作",
			dataIndex: ""
		}]
	};
	render() {
		return <section className="taskBox">
			<header className="headerBox">
				<h2>TASK OA 任务管理系统</h2>
				<Button type='primary'>新增</Button>
			</header>

			<nav className="navBox">
				<Tag color="#108ee9">全部</Tag>
				<Tag>未完成</Tag>
				<Tag>已完成</Tag>
			</nav>

			<Table columns={this.state.columns}></Table>
		</section>;
	}
}
export default Task;