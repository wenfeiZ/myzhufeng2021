<template>
    <div>
        grandSon
        {{$attrs}}{{name1}}
        <!-- {{$listeners.click()}}  -->
        {{parentMsg}}
    </div>
</template>
<script>
export default {
    inject:['parentMsg'],
    props:['name1'],
    methods:{
        fn2(){
            alert(2);
        }
    }
}
</script>