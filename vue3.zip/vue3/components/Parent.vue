<template>
    <div>
        parent 
        <!-- 父组件监听子组件的事件，并给事件绑定函数 -->
        <!-- <Son :m="money" @change="fn"></Son> -->
        <!-- 语法糖的写法 -->
        <!-- <Son :m.sync="money"></Son>   -->
        <!-- money绑定在属性value 绑定的事件名@input -->
         <!-- <Son :value="money" @input=" (data)=> money=data "></Son> -->
        <!-- <Son v-model="money"></Son> -->
        <son :name="{a:1}" :age="2" @click="fn1"  ></son>

    </div>
</template>
<script>
import Son from './Son';
export default {
    provide(){
        return {
            parentMsg:'parent'
        }
    },
    data(){
        return {
            money:500
        }
    },
    components:{
        Son
    },
    methods:{
        fn1(){
            alert(1)
        },
        fn(data){
           this.money  = data; 
        }
    }
}
</script>