<template>
    <div>
        son
        {{value}}
        {{a}}
        {{o}}
        {{$attrs}}
        {{$attrs.name}}
      
        <!-- {{$listeners.click()}} -->
        <!-- {{changeM}} -->
        <button @click="give">给父亲</button>
        <!-- <GrandSon v-bind="$attrs" :name="$attrs.name"></GrandSon> -->
        <GrandSon v-bind="$attrs" :name1="$attrs.name"  v-on="$listeners" ref="grandson"></GrandSon>
    </div>
</template>
<script>
import GrandSon from './GrandSon';
export default {
    //props:['m'],
    props:{
        value:{
            type:Number
        },
        m:{
            type:[String,Number],
            // default:100,
            //required:true,
            // validator:(value)=>{ //自定义验证规则
            //     return value>400&&value<1000
            // }
        },
        a:{
           type:Array,
           default:()=>[1]   //数组或对象 默认值得是函数
        },
        o:{
            type:Object,
            default:()=>({})
        }
    },
    methods:{
        give(){
            //子组件执行父组件监听的事件
            // this.$emit('change',1000)
            // this.$emit('update:m',1000)
            this.$emit('input',1000)
        }
    },
    components:{
        GrandSon
    },
    mounted(){ //DOM加载完成
            //this.$parent.fn1();
           // this.$children[0].fn2()
           this.$refs.grandson.fn2(); //ref 获取DOM元素和组件

    }
    // computed:{ //推荐用计算属性
    //     changeM(){
    //         return this.m.trim().toLowerCase()
    //     }
    // }
}
</script>