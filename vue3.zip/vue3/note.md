##组件
1.可复用 可以提高开发效率
2.方便后期的维护和修改
3.可以减少渲染

## 全局组件&局部组件
## 支持.vue后缀文件(快速原型开发)
npm install -g @vue/cli
npm install -g @vue/cli-service-global
 开发环境下 vue serve App.vue
 生产环境下 vue build App.vue

## 组件的通信
1.父子通信 props  $emit
2.$attrs(v-bind 批量的把属性往下传) $listeners(v-on 批量的把方法往下传)
3.provide inject 
4.$parent $children  ref
5.eventBus 兄弟之间传递数据 $on $emit
Vue.prototype.$bus = new Vue;
this.$bus.$on('test',function(data){console.log(data)})
this.$bus.$emit('test',1000)
