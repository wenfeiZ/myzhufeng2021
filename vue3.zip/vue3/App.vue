<template>
    <div>
        <Parent></Parent>
    </div>
</template>
<style scoped>

</style>
<script>
import Parent from './components/Parent';
export default {
    data(){
        return{

        }
    },
    components:{
        Parent
    }
}
</script>