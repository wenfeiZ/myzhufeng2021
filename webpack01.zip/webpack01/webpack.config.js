//配置文件 
//node commonJS规范 
const path = require('path');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
// console.log(path.resolve(__dirname,"dist"));
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin');//压缩css
const TerserJSPlugin = require('terser-webpack-plugin');
let htmlPlugin = ['index', 'other'].map(chunckName => {
    return new HtmlWebpackPlugin({
        template: `./${chunckName}.html`,
        filename: `${chunckName}.html`,
        chunks: [chunckName]
    })
})
module.exports = {
    // entry:"./src/index2.js", //单个的入口文件
    // output:{
    //     //hash chunkHash contentHash
    //     filename:'bundle.js',
    //     path:path.resolve(__dirname,"dist")
    // },
    optimization:{
        minimizer:[  //压缩的css,js
           new OptimizeCssAssetsPlugin(),
           new TerserJSPlugin()  
        ]
    },
    entry: {
        index: "./src/index.js",
        other: "./src/other.js"
    },
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, "dist")
    },
    devServer: { //在内存中打包，所有的内容是在根目录
        port: 7777,
        open: true,
        compress: true,
        contentBase: "static", //启动配置一个访问的静态资源文件
        hot: true
    },
    module: {
        rules: [
            //从下往上  从右往左
            // {
            //     test: /\.css$/,
            //     use: 'css-loader'
            // },
            // {
            //     test: /\.css$/,
            //     use: 'style-loader',
            //     enforce:'post'  //pre 优先加载 post最后加载
            // }

            {
                test: /\.css$/,
                //[]/{}/""
                use:[
                {
                    loader:MiniCssExtractPlugin.loader
                },
                {
                    loader:'css-loader',
                    options:{
                        importLoaders:2   //用后面的1个加载器来解析
                    }
                },'postcss-loader','less-loader'
            ] 
            },
            {
                test:/\.less$/,
                use:['style-loader','css-loader','less-loader']
            }
        ]
    },
    plugins: [
        // new CleanWebpackPlugin({
        //     cleanOnceBeforeBuildPatterns:['cc/*','!cc/a.js']
        // })  //清空输出的目录
        new MiniCssExtractPlugin({
            filename:'css/main.css'  //设置分离出css的目录及文件名
        }),
        new CleanWebpackPlugin(),
        ...htmlPlugin
        // new HtmlWebpackPlugin({
        //     template:"./index.html",//依赖的模板文件
        //     hash:true,
        //     minify:{
        //          removeAttributeQuotes:true, //删除引号
        //          collapseWhitespace:true //删除空格   
        //     },
        //     filename:"index.html",  // 打包后的html文件名
        //     chunks:['index']
        // }),
        // new HtmlWebpackPlugin({
        //     template:"./other.html",//依赖的模板文件
        //     hash:true,
        //     filename:"other.html",  // 打包后的html文件名
        //     chunks:['other']
        // })
    ]

}