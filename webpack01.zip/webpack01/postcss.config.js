module.exports = { //设置处理样式的配置文件
    plugins:[
        require('autoprefixer')
    ]
}