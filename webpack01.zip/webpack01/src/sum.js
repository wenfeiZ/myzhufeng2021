//esModule  commonJS
//esModule  import  export 
//commonJs  require module.exports

function sum(a,b){
    return a+b;
}
// export {sum}
export default sum;