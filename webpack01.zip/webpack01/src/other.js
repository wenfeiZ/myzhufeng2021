export default (a,b)=>{
    return a+b+100+200
}