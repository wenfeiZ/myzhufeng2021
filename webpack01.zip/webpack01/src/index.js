import sum from './sum';
import "./index.css";

console.log(sum(10,40));