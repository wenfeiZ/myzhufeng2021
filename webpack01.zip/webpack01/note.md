1.webpack作为前端构建工具的用途
代码转换 文件优化 代码分割 模块合并  自动刷新 代码校验 自动发布 

入口 出口 loader  plugins
webpack webpack-cli
html-webpack-plugin 
clean-webpack-plugin

webpack-dev-server  创建本地服务器，自动重新构建，自动打开浏览器并刷新

多入口文件 多出口
解析css   css-loader  style-loader
解析less   less less-loader
sass      node-sass sass-loader
stylus    stylus  stylus-loader 

处理css3私有前缀 postcss-loader (样式处理工具)  autoprefixer （私有前缀的插件）

分离css mini-css-extract-plugin