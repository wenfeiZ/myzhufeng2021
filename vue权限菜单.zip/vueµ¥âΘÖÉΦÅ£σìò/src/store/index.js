import Vue from 'vue'
import Vuex from 'vuex'
import {authRoutes} from '@/router/index.js'
import axios from 'axios';
axios.defaults.baseURL = "http://localhost:3000";
axios.interceptors.response.use(res=>res.data);
Vue.use(Vuex)

function getAuths(menuList) {
  //1.遍历menuList每一项 判断是否有auth，若有则把auth值存入数组，再判断是否有children，对children每一项进行循环判断  (递归和循环)
  //2.遍历menuList每一项 判断是否有auth，若有则把auth值存入数组，再判断是否有children,把children数组合并到menuList中，这样只需要变量MenuList就行 ->扁平化数据结构
  let menu = JSON.parse(JSON.stringify(menuList));//克隆数组或对象
  let index = 0;
  let arr = [];
  let current;
  //while 
  while (current = menu[index]) {
    arr.push(current.auth);
    if (current.children) {
      menu = menu.concat(current.children);
    }
    index++;
  }
  return arr;
}
const formateList = (authRoutes,auths)=>{
  return authRoutes.filter(route=>{
      if(auths.includes(route.name)){
          if(route.children){
            route.children = formateList(route.children,auths);
          }
        return true;
      }
  })
}

export default new Vuex.Store({
  state: {
    hasPermission:false,   //默认没有权限
    menuList:[],
    btnPermission:{
        add:true,
        edit:true
    }
  },
  mutations: {
    getNewRoute(state,payload){
      state.menuList = payload;
    },
    setPermisson(state,payload){
      state.hasPermission = true
    }
  },
  actions: {
   async getNewRoute({commit}){
     let {menuList}  = await axios.get('roleAuth');
     //console.log(menuList);  //权限数据
     commit('getNewRoute',menuList)  
    //根据权限数据设置菜单数据
    let auths = getAuths(menuList); //['cart','cart-list']
    let needRoutes = formateList(authRoutes,auths);
    commit('setPermisson');
    return needRoutes;
    }
  },
  modules: {
  }
})
