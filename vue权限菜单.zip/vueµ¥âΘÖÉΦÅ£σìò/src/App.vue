<template>
  <div id="app">
    <!-- <div id="nav">
     <Menu></Menu>
    </div>
    <router-view/> -->
    <el-button v-has="'edit'">编辑</el-button>
    <el-button v-has="'add'">添加</el-button>
  </div>
</template>
<script>
import Menu from '@/components/Menu';
export default {
  components:{
    Menu
  },
  directives:{
    has:{
      inserted(el,bindings,vnode){ //插入到DOM元素时执行
          //vnode.context 组件或实例
        let flag =   vnode.context.$store.state.btnPermission[bindings['value']]
        !flag && el.parentNode && el.parentNode.removeChild(el);
      }
    }
  }
}
</script>
<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
