import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

export const authRoutes = [  //所有动态路由
  {
    path: '/cart',
    name: "cart",
    component: () => import('@/views/Cart'),
    children: [
      {
        path: 'cart-list',
        name: 'cart-list',
        component: () => import('@/views/CartList'),
        children: [
          {
            path: 'lottery',
            name: 'lottery',
            component: () => import('@/views/Lottery')
          },
          {
            path: 'product',
            name: 'product',
            component: () => import('@/views/Product')
          }
        ]
      }
    ]
  }
]
const routes = [  //设置默认路由
  {
    path: '/',
    name: 'home',
    component: Home
  },
  {
    path: '*',
    component: {
      render: h => h('h1', {}, 'Not Fount')
    }
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
