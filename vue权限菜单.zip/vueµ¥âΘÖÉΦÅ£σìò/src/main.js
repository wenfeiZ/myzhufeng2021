import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import Axios from 'axios';
Vue.use(ElementUI);
Vue.config.productionTip = false
//全局守卫 在路由跳转前进行判断 beforeEach
router.beforeEach(async (to,from,next)=>{
  // console.log(store.state.hasPermission);
  if(!store.state.hasPermission){
    //向后端发起请求
    let needRoutes = await store.dispatch('getNewRoute');
    router.addRoutes(needRoutes);//添加动态路由
    next({...to});//刷新时还是有动态路由
  }else{
    next();
  }
}) 

new Vue({
  router,
  store,//$store
  render: h => h(App)
}).$mount('#app')
