<template>
    <div>
        lottery
    </div>
</template>