<template>
  <div>
    <el-submenu index="item.auth" v-if="item.children.length">
      <template slot="title">{{item.name}}</template>
       <template v-for="(m,index) in item.children">
           <MenuItem :item="m" :key="index"></MenuItem>
        </template> 
    </el-submenu>
    <el-menu-item  v-else index="item.auth">
        <router-link :to="{name:item.auth}">{{item.name}}</router-link>
        
        </el-menu-item>
  </div>
</template>
<script>
export default {
    name:'MenuItem',//组件名
    props:{
        item:{
            type:Object,
            default:()=>({})
        }
    }
}
</script>