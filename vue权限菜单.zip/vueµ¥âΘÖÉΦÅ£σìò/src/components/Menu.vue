<template>
<div>
<el-menu class="el-menu-demo" mode="vertical">
    <template v-for="(item,index) in $store.state.menuList" >
         <MenuItem :item="item" :key="index"></MenuItem>
    </template>
   
</el-menu>

</div>
</template>
<script>
import MenuItem from './MenuItem';
export default {
    components:{
        MenuItem
    }
}
</script>