import axios from '@/utils/ajaxRequest';
//提交用户名和密码
export const fetchUser = (user)=>{
    return axios.request({
        url:"/login",
        method:"post",
        data:user
    })
}

//验证是否登录
export const validateUser = ()=>{
    return axios.request({
        url:'/validate'
    })
}
