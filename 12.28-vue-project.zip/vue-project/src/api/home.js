import axios from '@/utils/ajaxRequest';
import store from '@/store'
//获取所有课程
export const fetchCategory = ()=>{
    return axios.request({
        url:'/category'
    })
}
//获取轮播图
export const fetchSlides  = ()=>{
    return axios.request({
        url:'/slides'
    })
}
//拉取数据
export const fetchNewLessonList = (size,offset)=>{
     return axios.request({
         url:`/lessonList/${store.state.home.currentLesson}?size=${size}&offset=${offset}`
     })   
}

