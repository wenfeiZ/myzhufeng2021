//axios实例的唯一性，各个实例之间都是独立的，不会相互污染
import axios from 'axios';
import { Toast } from "cube-ui";
class AjaxRequest {
    constructor(){
        this.baseURL = process.env.NODE_ENV !=="production"?'http://localhost:7000/api':'/',
        this.timeout=3000;//超时时间 
        this.queue = {};  //放请求的队列
    }
    setInterceptor(instance,url){
        //请求拦截
        instance.interceptors.request.use((config)=>{
          
            if(Object.keys(this.queue).length==0){ //如果没有请求过
              this.toast = Toast.$create({
                    time: 0,
                    txt: '正在加载'
                  }).show();
            }
            config.headers.token = localStorage.getItem('token')||"";
            this.queue[url] = url;
           return config;     
        },err=>{
            return Promise.reject(err.data)
        }) 
        //响应拦截
        instance.interceptors.response.use((res)=>{
            delete this.queue[url];
            if(Object.keys(this.queue).length==0){ //如果没有请求过
                this.toast.hide();
           }
            if(res.data.code ==0){
                return res.data.data;
            }else{
                return Promise.reject(res.data);
            }
        },err=>{
        //     delete this.queue[url];
        //     if(Object.keys(this.queue).length==0){ //如果没有请求过
        //         this.toast.hide();
        //    }
            return Promise.reject(err.data)
        }) 

    }
    request(options){
        let instance = axios.create(); //创建了axios实例
        let config = {
            baseURL:this.baseURL,
            timeout:this.timeout,
            ...options
        }
        this.setInterceptor(instance,options.url); //对拦截器进行处理
        return instance(config);
    }
}
export default new AjaxRequest;
// new AjaxRequest().request({
//     url:XXX,
//     data
// })

