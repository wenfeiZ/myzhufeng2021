import Vue from 'vue';
import VueRouter from 'vue-router';
import Home from '@/views/Home';
import permission from './permission';

Vue.use(VueRouter);
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

const routes = [
  {
    path: '/',
    name: 'home',
    component: Home,
  },
  {
    path: '/course',
    name: 'course',
    meta:{
      needLogin:true
    },
    component: () => import( '@/views/Course'),
  },
  {
    path: '/profile',
    name: 'profile',
    component: () => import( '@/views/Profile'),
  },
  {
    path: '/login',
    name: 'login',
    component: () => import( '@/views/Login'),
  },
  {
    path:'*',
    component:{
      render(){
        return <h1>找不到</h1>
      }
    }
  }

];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});
Object.values(permission).forEach(hook=>{
    router.beforeEach(hook);
})

export default router;
