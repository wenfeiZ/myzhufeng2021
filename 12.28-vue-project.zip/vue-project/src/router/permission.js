import store from '@/store';
import * as types from "@/store/types";
export default {
    validateLogin : async (to,from,next)=>{
        //检验是否登录过
        try{
            await store.dispatch(types.VALIDATE_USER);
            if(to.name =="login"){
                next('/')
            }else{
                next()
            }
        }catch(e){
            //没有登录过
          let needLogin = to.matched.some(item=>item.meta.needLogin);
          if(needLogin){
              next('/login')
          }else{
              next();
          }
        }
         
    }
}