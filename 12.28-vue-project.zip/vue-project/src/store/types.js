//获取分类数据
export const SET_CATEGORIES = "SET_CATEGORIES"
//获取轮播图数据
export const SET_SLIDES="SET_SLIDES"
export const SET_LESSON = "SET_LESSON"

export const SET_LOGIN = "SET_LOGIN"

export const VALIDATE_USER = "VALIDATE_USER"