import {fetchCategory,fetchSlides} from '@/api/home';
import * as types from '@/store/types';
export default {
    namespaced:true,
    state: {
        category:[],
        slides:[],
        currentLesson:-1
    },
    mutations: {
        [types.SET_SLIDES](state,payload){
             state.slides =payload;
        } ,
        [types.SET_CATEGORIES](state,payload){
            state.category =payload;
       },
       [types.SET_LESSON] (state,payload){
           state.currentLesson  = payload
       }
    },
    actions: {
        async [types.SET_SLIDES]({commit}){
           let  slides =  await fetchSlides();
           commit(types.SET_SLIDES,slides);
        },
        async [types.SET_CATEGORIES]({commit}){
            let  category =  await fetchCategory();
            commit(types.SET_CATEGORIES,category);
         }
    },
    modules: {
    },
  };