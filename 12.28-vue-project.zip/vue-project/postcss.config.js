module.exports = {
  plugins: {
    'postcss-px2rem': {
      remUnit: 37.5,  //1rem = 37.5px
    },
  },
};
