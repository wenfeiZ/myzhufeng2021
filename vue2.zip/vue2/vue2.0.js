//数据改变时，视图更改

let oldArrayPrototype = Array.prototype;
let proto = Object.create(oldArrayPrototype); //继承
['push','shift','unshift','splice'].forEach(method=>{ //函数劫持 把函数进行重写，内部会继续调用老的方法
        proto[method]=function(){
            updateView();
            oldArrayPrototype[method].call(this,...arguments);
        }
       
})

function observe(target){
   if(typeof target !='object' ||target ==null){
       return target;
   }
   if(Array.isArray(target)){
       Object.setPrototypeOf(target,proto);
       //target.__proto__= proto;
       for(let i = 0;i<target.length;i++){
           observe(target[i]);
       }
   }

   
    //对对象中的每个属性进行监视
    for(let key in target){
        defineReactive(target,key,target[key]) 
    }
}
function defineReactive(target,key,value){ //响应式系统
    observe(value);//递归调用 对对象继续进行拦截
    Object.defineProperty(target,key,{
        get(){ //获取属性值
            return value;
        },
        set(newVal){//设置属性值
            if(newVal !==value){
                observe(newVal);
                updateView();
                value = newVal;
            }
        }
    })
}

function updateView(){
    console.log('更新视图')
}

//let data = {name:{m:{n:20}}}  //Object.defineProperty  get set
let data = {name:[1,2,3]}
observe(data);
data.name.push(4);//push ,shift,unshift,splice.... 经过重写数组 

//data.name  //get
//data.name = "zhufengpeixun" //set
//data.name="zhufeng";
// data.name = {m:30};
// data.name.m = 20;
// data.name.m = {n:40};
// data.name.m.n = 30;
//data.age = 10;//若属性不存在，不会响应式