<template>
    <div>
        <el-tree :data="allData" 
        :render-content="render"
        default-expand-all
        :expand-on-click-node ="false"
        ></el-tree>
    </div>
</template>
<script>
import _ from 'lodash';
export default {
    props:{
        data:{
            type:Array,
            default:()=>[]
        },
        directoryDrop:Array,
        fileDrop:Array,
        deleteFn:Function
    },
    data(){
        return {
            allData:[],
            currentId:'', //修改的元素
            currentContent:'' //输入框里面的内容
        }
    },
    watch:{
        data(){
             this.transformData();   
        }
    },
    methods:{
    /*  [
        {"name":"文件夹1","pid":0,"id":1,"type":"parent"},
        {"name":"文件夹2","pid":0,"id":2,"type":"parent"},
        {"name":"文件夹3","pid":0,"id":3,"type":"parent"},
        {"name":"文件夹1-1","pid":1,"id":4,"type":"parent"},
        {"name":"文件夹2-1","pid":2,"id":5,"type":"parent"},
        {"name":"文件1","pid":1,"id":10001},
        {"name":"文件2","pid":1,"id":10002},
        {"name":"文件2-1","pid":2,"id":10003},
        {"name":"文件2-2","pid":2,"id":10004},
        {"name":"文件1-1-1","pid":4,"id":10005},
        {"name":"文件2-1-1","pid":5,"id":10006}
        ]
        {
          1: {"name":"文件夹1","pid":0,"id":1,"type":"parent"} 
        }
    */
        transformData(){  //格式化数据
            let allData = _.cloneDeep(this.data);
            let treeMapList = allData.reduce((obj,current)=>{
                   current.label = current.label|| current.name;
                   obj[current['id']] = current; 
                   return obj;
            },{})
            let result = allData.reduce((arr,current)=>{
                    let pid = current.pid;
                    let parent = treeMapList[pid];
                    if(parent){
                        parent.children?parent.children.push(current):(parent.children=[current])
                    }else if(pid == 0){
                        arr.push(current)
                    }
                    return arr;
            },[])
                this.allData = result
        },
        isParent(data){
            return data.type =="parent"
        },
        handleCommand(data,value){
                //this 表示的是vue实例
                if(value =="rn"){
                    this.handleRename(data);
                }else if(value =="rm"){
                    this.handleRemove(data);
                }
        },
        handleRename(data){
             this.currentId = data.id;
             this.currentContent = data.label; //设置默认值
        },
        handleRemove(data){
            this.$confirm(`此操作将永久删除该文件${data.label}, 是否继续?`, '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
            }).then(() => {
                this.deleteFn ? this.deleteFn().then(()=>{
                      this.remove(data);
                }):this.remove(data);
              
            }).catch(() => {
            this.$message({
                type: 'info',
                message: '已取消删除'
            });          
        });   
        },
        remove(data){
            let lists = _.cloneDeep(this.data); 
            lists = lists.filter(l=>l.id != data.id);
            this.$emit('update:data',lists); 
            this.$message({
            type: 'success',
            message: "删除成功"
            });
        },
        handleInput(v){
            this.currentContent = v;
        },
        ok(data){
           let lists = _.cloneDeep(this.data); 
           let list = lists.find(l=>l.id == data.id);
           this.currentId = "";
           list.label = this.currentContent;
           this.$emit('update:data',lists);
            this.$message({
              type: 'success',
              message: "修改成功"
            });
        },
        cancel(){
            this.currentId ="";
        },
        render(h, { node, data, store }){
             //jsx =js+xml  {}  
             let lists = this.isParent(data)?this.directoryDrop:this.fileDrop;
              return  (
                <div style={{width:'100%'}}> 
                {
                    this.isParent(data)?
                    (node.expanded ? 
                    <i class="el-icon-folder-opened"></i>:
                     <i class="el-icon-folder"></i>):
                     <i class="el-icon-document"></i>
                }
                {
                    this.currentId == data.id?
                    <el-input value={this.currentContent} on-input ={this.handleInput}></el-input>:
                    data.label
                }
                 
                 {
                   this.currentId == data.id? <span>
                   <el-button type="text" on-click={this.ok.bind(this,data)}>确定</el-button>
                   <el-button type="text" on-click={this.cancel}>取消</el-button>
                   </span> :  
                 <el-dropdown on-command={this.handleCommand.bind(this,data)} trigger="click">
                    <span class="el-dropdown-link">
                        <i class="el-icon-arrow-down el-icon--right"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                    {
                        lists.map(item=>(
                          <el-dropdown-item command={item.text}>{item.value}</el-dropdown-item> 
                        ))
                    }
                       
                    </el-dropdown-menu>
                    </el-dropdown>   
                 }   
                       
                </div>
               )
        }
    },
    mounted(){
        this.transformData();
    }
}
</script>
<style>
    .el-tree{
        width: 100%;
    }
    .el-tree .el-dropdown{
        float:right;
    }
    .el-tree .el-input{
        width: 50%;
    }
    .el-tree .el-tree-node__content{
        height: 35px
    }
</style>