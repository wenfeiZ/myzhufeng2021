import axios from 'axios';
axios.defaults.baseURL = "http://localhost:9000" //设置下请求的公共路径部分
export const getTreeList = ()=>{
    return axios.get('/getTreeList');
}