<template>
  <div>
    <Tree :data.sync="data" :fileDrop = 'fileDrop' :directoryDrop ="directoryDrop"  :deleteFn ="deleteFn"></Tree>
  </div>
</template>
<script>
import Tree from './Tree';
import { getTreeList } from './api';
export default {
  data(){
    return {
      data:[],
      fileDrop:[
        {text:'rm',value:'删除文件'}
      ],
      directoryDrop:[
        {text:'rn',value:'修改名字'},
        {text:'rm',value:'删除文件'}
      ]
    }
  },
  methods:{
    deleteFn(){
      return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve();
        },2000)
      })
    }
  },
  async created(){
    let {data} =   await getTreeList()
     data.parent.forEach(p=>p.type="parent"); 
     this.data = [...data.parent,...data.child];
    
  },
  components:{
    Tree
  }
}
</script>